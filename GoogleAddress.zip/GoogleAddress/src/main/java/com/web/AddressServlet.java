package com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.AddressManager;
import com.AddressVO;


/**
 * Servlet designed to register and login a user
 *
 * @author wbustraa
 */
public class AddressServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    
    /** Class logging facility. */
    public static final Logger LOG = Logger.getLogger(AddressServlet.class);

    /** Path to DataSource in JNDI */
    public static final String JNDI_PATH_DB = "jdbc/AddressDB";

    @Override
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
                                                                                              IOException {
        doPost(request, response);
    }

    @Override
    public void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
                                                                                               IOException {
        final String action = request.getParameter("action");
        System.out.println(action);
        if (action.equals("index")) {
            index(request, response);
        } else if (action.equals("addAddress")) {
        	processRequest(request, response);
        } else {
            doViewAddressDetails(request, response);
        }
    }

    private void index(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	redirect(request, response, "index.jsp", false);
		
	}


	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	System.out.println("addadress called");
    	final String addressStr = request.getParameter("address");
    	System.out.println("add : "+addressStr);
    	AddressManager manager = new AddressManager();
    	
    	manager.processRequest(addressStr, request,response);
    	 
 	}

    /**
     * Perform the 'view' action
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    public void doViewAddressDetails(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
                                                                                                          IOException {

        AddressVO address = getAddress(request);
        if (address == null) {
            sendError(request, response, "No address found");
        } else {
        	request.setAttribute("address", address);
            redirect(request, response, "/address.jsp", true);
        }
//        closeConnection();
    }

    public AddressVO getAddress(final HttpServletRequest request) {
        final HttpSession session = request.getSession();
        AddressVO address = (AddressVO)request.getSession().getAttribute(AddressManager.ADDRESS_ID);
        
        return address;
    }



    /**
     * Redirect to another page
     *
     * @param request
     * @param response
     * @param path
     * @param forward
     * @throws ServletException
     * @throws IOException
     */
    public void redirect(final HttpServletRequest request,
                         final HttpServletResponse response,
                         final String path,
                         final boolean forward) throws ServletException, IOException {
        if (forward) {
            final RequestDispatcher dispatcher = request.getRequestDispatcher(path);
            dispatcher.forward(request, response);
        } else {
            response.sendRedirect(path);
        }
    }

    /**
     * Redirect the user to an error page.
     *
     * @param request
     * @param response
     * @param errorMessage
     * @throws ServletException
     * @throws IOException
     */
    public void sendError(final HttpServletRequest request,
                          final HttpServletResponse response,
                          final String errorMessage) throws ServletException, IOException {
        request.setAttribute("errorMessage", errorMessage);
        redirect(request, response, "/error.jsp", true);
    }

}
