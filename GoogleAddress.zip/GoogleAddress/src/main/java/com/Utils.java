package com;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.i18n.phonenumbers.PhoneNumberMatch;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;

public class Utils {
	private static String pattern = "\\b[a-zA-Z0-9.-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z0-9.-]+\\b"; //Email Address Pattern
	private static final Set<String> fCOMMON_WORDS = new LinkedHashSet<>();
	static {
	    fCOMMON_WORDS.add(" a ");
	    fCOMMON_WORDS.add(" and ");
	    fCOMMON_WORDS.add(" be ");
	    fCOMMON_WORDS.add(" for ");
	    fCOMMON_WORDS.add(" from ");
	    fCOMMON_WORDS.add(" has ");
	    fCOMMON_WORDS.add(" i ");
	    fCOMMON_WORDS.add(" in ");
	    fCOMMON_WORDS.add(" is ");
	    fCOMMON_WORDS.add(" it ");
	    fCOMMON_WORDS.add(" of ");
	    fCOMMON_WORDS.add(" on ");
	    fCOMMON_WORDS.add(" to ");
	    fCOMMON_WORDS.add(" the ");
	    fCOMMON_WORDS.add(" with ");
	    fCOMMON_WORDS.add(" address ");
	    fCOMMON_WORDS.add(" remove ");
	    fCOMMON_WORDS.add(" delete ");
	    fCOMMON_WORDS.add(" please ");
	    fCOMMON_WORDS.add(" plz ");
	    fCOMMON_WORDS.add(" pls ");
	    fCOMMON_WORDS.add(" records ");
	    fCOMMON_WORDS.add(" db ");
	    fCOMMON_WORDS.add(" database ");

	  }
	private static String[] prefixes = { "dr ","dr. ", "mr ", "mr. ", "ms ", "atty ", "prof ", "miss ", "mrs " };
	
	public static String removeCommonWords(String txt){
		if(txt == null || txt.trim().isEmpty()){
			return null;
		}
				
		txt += " ";
		for (String string : fCOMMON_WORDS) {
//			System.out.println(string);
			//if(txt.toLowerCase().contains(string)){
				//System.out.println("contain "+string);
				txt = txt.replaceAll("(?i)"+string, " ");
//			}
		}
		
		return txt;
	}
	
	public static NameVO parseName(String txt){
		if(txt == null || txt.trim().isEmpty()){
			return null;
		}
		
		NameVO name = new NameVO();
		
		txt = removeCommonWords(txt);
		
		for (String string : prefixes) {
			if(txt.toLowerCase().startsWith(string)){
				txt = txt.replaceAll("(?i)"+string, " ");
				name.setTitle(string);
				break;
			}
		}
		System.out.println(txt);
		String[] nameStr = txt.trim().split(" ");
		name.setFirstName(nameStr[0]);
		if(nameStr.length > 2){
			name.setMiddleName(nameStr[1]);
			name.setLastName(nameStr[nameStr.length -1]);
		}else if(nameStr.length == 2){
			name.setLastName(nameStr[1]);
		}
		
		System.out.println("returning "+name);
		return name;
	}
	
	public static List<PhoneNumber> getPhone(String txt){
		PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		Iterable<PhoneNumberMatch> numbers = phoneUtil.findNumbers(txt, Locale.US.getCountry());
		 Iterator<PhoneNumberMatch> existsPhone=PhoneNumberUtil.getInstance().findNumbers(txt, Locale.US.getCountry()).iterator();
	    
		 List<PhoneNumber> phones = new ArrayList<PhoneNumber>();
		 
		 while (existsPhone.hasNext()){
		       // System.out.println("Phone == " + existsPhone.next().number());
		        phones.add( existsPhone.next().number());
		    }
		 System.out.println(phones);
		 return phones;
	    /*numbers.forEach(number -> {
	        String s = number.rawString();
	        // your phone numbers
	        System.out.println(s);
	    });*/
	    /*return data;*/
	}

	public static String removePhoneData(String request) {
		
		if(request.toLowerCase().lastIndexOf("phone") > 0){
			request = request.substring(0,request.toLowerCase().lastIndexOf("phone"));
		}
		
		if(request.toLowerCase().lastIndexOf("email") > 0){
			request = request.substring(0,request.toLowerCase().lastIndexOf("email"));
		}
		
		if(request.toLowerCase().lastIndexOf(" mail") > 0){
			request = request.substring(0,request.toLowerCase().lastIndexOf(" mail"));
		}
		
		return request;
	}
	
	public static Set<String> extractEmail(String txt) {
		Set<String> emailAddresses = new HashSet<>(); //Contains unique email addresses
        //Creates a Pattern
        Pattern pat = Pattern.compile(pattern);
        //Matches contents against the given Email Address Pattern
        Matcher match = pat.matcher(txt);
        //If match found, append to emailAddresses
        while(match.find()) {
            emailAddresses.add(match.group());
        }
        return emailAddresses;
    }
	
	public static void main(String[] args) {
	      String request = "Add Mr. Bob Sanders with the address Any St. New York New York, 12345 phone 4695555555 office (972)-444-6666 mail abcd@bb.com and xyz@gmail.com";

		Utils.getPhone(request);
		System.out.println(Utils.extractEmail(request));
	}

}
