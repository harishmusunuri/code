package com.dao;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class DatabaseConnectionManager {

	public Connection getConnection() {

		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return DriverManager.getConnection("jdbc:mysql://localhost:3306/address", "root", "root");
		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			ex.printStackTrace();
		}
		return null;
	}

	/**
	 * Close dabase connection
	 */
	public void closeConnection(Connection con) {
		try {
			con.close();
		} catch (final SQLException ex) {
			System.err.println(ex.getMessage());
			ex.printStackTrace();
		}
	}
}
