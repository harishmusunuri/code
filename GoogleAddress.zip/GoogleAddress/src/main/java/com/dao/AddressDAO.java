package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.AddressVO;
import com.NameVO;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;

public class AddressDAO {

	public void insertPhone(AddressVO address, int addid) {
		if (address == null || address.getPhoneNumbers() == null || address.getPhoneNumbers().isEmpty()) {
			return;
		}

		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "insert into phone (addressid, phone)" + " values(?,?)";

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			for (PhoneNumber phone : address.getPhoneNumbers()) {
				preparedStmt.setInt(1, addid);
				preparedStmt.setString(2, "" + phone.getNationalNumber());
				preparedStmt.addBatch();
			}

			// execute the preparedstatement
			preparedStmt.executeBatch();

			preparedStmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}
	}

	public void insertEmail(AddressVO address, int addid) {
		if (address == null || address.getEmails() == null || address.getEmails().isEmpty()) {
			return;
		}

		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "insert into email (addressid, email)" + " values(?,?)";

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			for (String email : address.getEmails()) {
				preparedStmt.setInt(1, addid);
				preparedStmt.setString(2, email);
				preparedStmt.addBatch();
			}

			// execute the preparedstatement
			preparedStmt.executeBatch();

			preparedStmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}
	}

	public void insertAddress(AddressVO address) {
		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "insert into address (FirstName, LastName, MiddleName, Title, StreetNumber, StreetName, Type, Line2, City,State,Zip,Country)"
				+ " values(?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			preparedStmt.setString(1, address.getName().getFirstName());
			preparedStmt.setString(2, address.getName().getLastName());
			preparedStmt.setString(3, address.getName().getMiddleName());
			preparedStmt.setString(4, address.getName().getTitle());
			preparedStmt.setString(5, address.getNumber());
			preparedStmt.setString(6, address.getStreet());
			preparedStmt.setString(7, address.getType());
			preparedStmt.setString(8, address.getLine2());
			preparedStmt.setString(9, address.getCity());
			preparedStmt.setString(10, address.getState());
			preparedStmt.setString(11, address.getZip());
			preparedStmt.setString(12, address.getCountry());

			// execute the preparedstatement
			preparedStmt.execute();

			ResultSet rs = preparedStmt.getGeneratedKeys();
			int addId = -1;
			if (rs.next()) {
				addId = rs.getInt(1);
			}
			preparedStmt.close();
			insertPhone(address, addId);
			insertEmail(address, addId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}
	}

	public AddressVO findAddressByName(NameVO name) {
		AddressVO vo = null;

		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "select id, FirstName, LastName, MiddleName, Title, StreetNumber, StreetName, Type, Line2, City,State,Zip,Country "
				+ " from address where firstName = ? and lastName= ? ";

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql);
			preparedStmt.setString(1, name.getFirstName());
			preparedStmt.setString(2, name.getLastName());

			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {
				vo = new AddressVO();
				vo.setId(rs.getInt("id"));
				vo.getName().setFirstName(rs.getString("FirstName"));
				vo.getName().setLastName(rs.getString("LastName"));
				vo.getName().setTitle(rs.getString("Title"));
				vo.setCity(rs.getString("City"));
				vo.setNumber(rs.getString("StreetNumber"));
				vo.setStreet(rs.getString("StreetName"));
				vo.setState(rs.getString("State"));
				vo.setType(rs.getString("Type"));
				vo.setLine2(rs.getString("Line2"));
				vo.setCountry(rs.getString("Country"));
				vo.setZip(rs.getString("Zip"));
				vo.setPhoneNumbers(findPhonesByAddressId(vo.getId()));
				vo.setEmails(findEmailByAddressId(vo.getId()));
			}
			preparedStmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}

		return vo;
	}

	public AddressVO findAddressByName(int id) {
		AddressVO vo = null;

		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "select id, FirstName, LastName, MiddleName, Title, StreetNumber, StreetName, Type, Line2, City,State,Zip,Country "
				+ " from address where id = ? ";

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql);
			preparedStmt.setInt(1, id);

			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {
				vo = new AddressVO();
				vo.setId(rs.getInt("id"));
				vo.getName().setFirstName(rs.getString("FirstName"));
				vo.getName().setLastName(rs.getString("LastName"));
				vo.getName().setTitle(rs.getString("Title"));
				vo.setCity(rs.getString("City"));
				vo.setNumber(rs.getString("StreetNumber"));
				vo.setStreet(rs.getString("StreetName"));
				vo.setState(rs.getString("State"));
				vo.setType(rs.getString("Type"));
				vo.setLine2(rs.getString("Line2"));
				vo.setCountry(rs.getString("Country"));
				vo.setZip(rs.getString("Zip"));
				vo.setPhoneNumbers(findPhonesByAddressId(vo.getId()));
				vo.setEmails(findEmailByAddressId(vo.getId()));
			}
			preparedStmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}

		return vo;
	}

	public Set<String> findEmailByAddressId(int addid) {
		Set<String> emails = new HashSet<String>();
		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "select email from email where addressid= ? ";

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql);
			preparedStmt.setInt(1, addid);

			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {
				emails.add(rs.getString("email"));
			}
			preparedStmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}

		return emails;
	}

	public List<PhoneNumber> findPhonesByAddressId(int addid) {
		List<PhoneNumber> phones = new ArrayList<PhoneNumber>();
		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "select phone from phone where addressid= ? ";

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql);
			preparedStmt.setInt(1, addid);

			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {
				PhoneNumber number = new PhoneNumber();
				number.setNationalNumber(rs.getLong("phone"));
				phones.add(number);
			}
			preparedStmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}

		return phones;
	}

	public int findAddressIdForPhone(long phone) {
		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "select addressid,phone from phone where phone= ? ";
		int id = -1;

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql);
			preparedStmt.setLong(1, phone);

			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {

				id = rs.getInt("addressid");
			}
			preparedStmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}

		return id;
	}
	public int findAddressIdForEmail(String email) {
		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "select addressid,email from email where email= ? ";
		int id = -1;

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql);
			preparedStmt.setString(1, email);

			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {

				id = rs.getInt("addressid");
			}
			preparedStmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}

		return id;
	}

	public void deleteAddressById(int id) {
		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "delete from address where id=? ";

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql);
			preparedStmt.setInt(1, id);

			preparedStmt.execute();

			preparedStmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}

	}

	public AddressVO deleteAddress(NameVO name) {
		// TODO Auto-generated method stub
		AddressVO vo = findAddressByName(name);
		deleteAddressById(vo.getId());

		deleteEmails(vo.getId());
		deletePhones(vo.getId());
		return vo;
	}

	public void deleteEmails(int addressid) {

		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "delete from email where addressid=? ";

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql);
			preparedStmt.setInt(1, addressid);

			preparedStmt.execute();

			preparedStmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}
	}

	public void deletePhones(int addressid) {

		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "delete from phone where addressid=? ";

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql);
			preparedStmt.setInt(1, addressid);

			preparedStmt.execute();

			preparedStmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}
	}

	public AddressVO deleteAddressByPhone(long nationalNumber) {
		// TODO Auto-generated method stub
		int addid = findAddressIdForPhone(nationalNumber);
		AddressVO address = findAddressByName(addid);
		deleteAddressById(addid);

		return address;
	}
	public AddressVO findAddressByPhone(long nationalNumber) {
		// TODO Auto-generated method stub
		int addid = findAddressIdForPhone(nationalNumber);
		AddressVO address = findAddressByName(addid);
//		deleteAddressById(addid);

		return address;
	}

	public AddressVO findAddressByEmail(String email) {
		// TODO Auto-generated method stub
		int addid = findAddressIdForEmail(email);
		AddressVO address = findAddressByName(addid);
//		deleteAddressById(addid);

		return address;
	}

	public int findTotalRecords() {

		DatabaseConnectionManager dbM = new DatabaseConnectionManager();
		Connection con = dbM.getConnection();

		String sql = "select count(*) from address";
		int count = 0;

		try {
			PreparedStatement preparedStmt = con.prepareStatement(sql);
			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {

				count = rs.getInt(1);
			}
			preparedStmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbM.closeConnection(con);
		}

		
		return count;
	}
}
