package com;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AddressDAO;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;

import net.sourceforge.jgeocoder.AddressComponent;
import net.sourceforge.jgeocoder.us.AddressParser;

public class AddressManager {
	/** Address key. */
	public static final String ADDRESS_ID = "ADDRESS_ID";
	public static final String OPERATION = "OPERATION";
	public static final String TOTAL_COUNT = "TOTAL_COUNT";

	public void processRequest(String request, final HttpServletRequest hreq, final HttpServletResponse response)
			throws ServletException, IOException {

		if (request == null || request.trim().isEmpty()) {
			return;
		}
		HttpSession session = hreq.getSession();

		if (request.toLowerCase().startsWith("add ") || request.toLowerCase().startsWith("insert")
				|| request.toLowerCase().startsWith("save") || request.toLowerCase().startsWith("store")) {
			AddressVO address = storeAddress(request);

			session.setAttribute(ADDRESS_ID, address);
			session.setAttribute(OPERATION, "add address");
			redirect(hreq, response, hreq.getParameter("successUrl"), false);
		} else if (request.toLowerCase().startsWith("remove") || request.toLowerCase().startsWith("delete")) {
			AddressVO address = removeAddress(request);

			session.setAttribute(ADDRESS_ID, address);
			session.setAttribute(OPERATION, "delete address");
			redirect(hreq, response, "address?action=view", false);
		} else if (request.toLowerCase().startsWith("what") || request.toLowerCase().startsWith("find")
				|| request.toLowerCase().startsWith("locate") || request.toLowerCase().startsWith("search")) {
			AddressVO address = searchAddress(request);
			System.out.println("got address " + address);
			if (address != null) {
				session.setAttribute(ADDRESS_ID, address);
				session.setAttribute(OPERATION, "search address");
				redirect(hreq, response, "address?action=view", false);
			} else {
				session.setAttribute(OPERATION, request);
				redirect(hreq, response, "nodatafound.jsp", false);
			}
		} else if (request.toLowerCase().contains("total") || request.toLowerCase().contains("how many")) {
			int count = findTotalAddresses();
			System.out.println("got total count " + count);
			session.setAttribute(TOTAL_COUNT, Integer.valueOf(count));
			session.setAttribute(OPERATION, "total records in address book");
			redirect(hreq, response, "totalrecords.jsp", false);
		}

	}

	private int findTotalAddresses() {

		AddressDAO dao = new AddressDAO();
		return dao.findTotalRecords();

	}

	private AddressVO searchAddress(String request) {
		// TODO Auto-generated method stub
		AddressDAO dao = new AddressDAO();
		request = request.substring(request.indexOf(" ") );
		List<PhoneNumber> phones = Utils.getPhone(request);
		System.out.println(Utils.getPhone(request));
		List<AddressVO> addresses = new ArrayList<AddressVO>();
		AddressVO vo = null;
		if (phones != null && !phones.isEmpty()) {
			for (PhoneNumber phoneNumber : phones) {
				vo = dao.findAddressByPhone(phoneNumber.getNationalNumber());
				return vo;
			}
		}
		Set<String> emails = Utils.extractEmail(request);
		if (emails != null && !emails.isEmpty()) {
			for (String email : emails) {
				vo = dao.findAddressByEmail(email);
				return vo;
			}
		}

		request = Utils.removeCommonWords(request);
		Map<AddressComponent, String> addressComponents = AddressParser.parseAddress(request);
		if (addressComponents == null) {
			NameVO name = Utils.parseName(request);
			if (name != null && name.getFirstName() != null
					|| vo.getName().getFirstName().trim().length() > 0) {
				vo = dao.findAddressByName(name);
				return vo;
			}
		} else {

			System.out.println(addressComponents);
			vo.setName(getName(addressComponents.get(AddressComponent.NAME)));

			if (vo.getName() != null && vo.getName().getFirstName() != null
					|| vo.getName().getFirstName().trim().length() > 0) {
				vo = dao.findAddressByName(vo.getName());
				return vo;
			}
		}
		return new AddressVO();
	}

	private AddressVO removeAddress(String request) {
		request = request.substring(request.indexOf(" ") + 1);
		request = Utils.removeCommonWords(request);
		NameVO name = Utils.parseName(request);
		System.out.println(name);
		AddressVO address = new AddressDAO().deleteAddress(name);
		return address;
	}

	private AddressVO storeAddress(String request) {
		AddressVO address = new AddressVO();

		request = request.substring(request.indexOf(" "));

		System.out.println(Utils.getPhone(request));
		address.setPhoneNumbers(Utils.getPhone(request));
		address.setEmails(Utils.extractEmail(request));
		if (address.getPhoneNumbers() != null && address.getPhoneNumbers().size() > 0) {
			// having phone, remove phone from the text
			request = Utils.removePhoneData(request);
		} else if (address.getEmails() != null || !address.getEmails().isEmpty()) {
			request = Utils.removePhoneData(request);
		}
		System.out.println("removed phone " + request);
		Map<AddressComponent, String> addressComponents = AddressParser.parseAddress(request);

		System.out.println(addressComponents);
		address.setName(getName(addressComponents.get(AddressComponent.NAME)));
		address.setCity(addressComponents.get(AddressComponent.CITY));
		address.setNumber(addressComponents.get(AddressComponent.NUMBER));
		address.setStreet(addressComponents.get(AddressComponent.STREET));
		address.setLine2(addressComponents.get(AddressComponent.LINE2));
		address.setState(addressComponents.get(AddressComponent.STATE));
		address.setZip(addressComponents.get(AddressComponent.ZIP));
		address.setType(addressComponents.get(AddressComponent.TYPE));

		System.out.println(address);
		AddressDAO dao = new AddressDAO();
		dao.insertAddress(address);
		return address;
	}

	public NameVO getName(String str) {
		if (str == null || str.trim().isEmpty()) {
			return null;
		}

		return Utils.parseName(str);

	}

	public static void main(String[] args) {
		// Map<AddressComponent, String> addressComponents =
		// AddressParser.parseAddress("6501 independence pkwy apt 555 plano tx
		// 75023");
		// System.out.println(addressComponents);
		//
		AddressManager address = new AddressManager();

		String request = "Add Mr. Bob Sanders with the address 123 Any St. New York New York, 12345  phone 4695555555 office (972)-444-6666 mail abcd@bb.com and xyz@gmail.com";
		// address.processRequest(request);
		// address.processRequest("remove Jack Barclay from database");

	}

	public void redirect(final HttpServletRequest request, final HttpServletResponse response, final String path,
			final boolean forward) throws ServletException, IOException {
		if (forward) {
			final RequestDispatcher dispatcher = request.getRequestDispatcher(path);
			dispatcher.forward(request, response);
		} else {
			response.sendRedirect(path);
		}
	}

}
