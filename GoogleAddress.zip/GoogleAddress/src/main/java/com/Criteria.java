package com;

public class Criteria {

	
}
