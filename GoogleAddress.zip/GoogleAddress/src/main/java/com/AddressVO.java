package com;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;

public class AddressVO {

	private int id;
	private NameVO name = new NameVO();
	private String number;
	private String street;
	private String type;
	private String line2;
	private String city;
	private String state;
	private String zip;
	private String country;
	private List<PhoneNumber> phoneNumbers = new ArrayList<PhoneNumber>();
	private Set<String> emails = new HashSet<String>();
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public List<PhoneNumber> getPhoneNumbers() {
		return phoneNumbers;
	}
	public void setPhoneNumbers(List<PhoneNumber> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}

	
	public Set<String> getEmails() {
		return emails;
	}
	public void setEmails(Set<String> emails) {
		this.emails = emails;
	}
	public NameVO getName() {
		return name;
	}
	public void setName(NameVO name) {
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLine2() {
		return line2;
	}
	public void setLine2(String line2) {
		this.line2 = line2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getNormalizedStreet(){
		String line2 = this.line2;
		String type= this.type;
		if(this.line2 == null){
			line2 = "";
		}
		if(this.type ==null){
			type="";
		}
		return number+" "+street+" "+type+" "+line2;
	}
	
	
	@Override
	public String toString() {
		return "AddressVO [name=" + name + ", number=" + number + ", street=" + street + ", type=" + type + ", line2="
				+ line2 + ", city=" + city + ", state=" + state + ", zip=" + zip + ", country=" + country
				+ ", phoneNumbers=" + phoneNumbers + ", emails=" + emails + ", getNormalizedStreet()="
				+ getNormalizedStreet() + "]";
	}
}
