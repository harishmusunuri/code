

CREATE TABLE address (
    ID int  NOT NULL AUTO_INCREMENT PRIMARY KEY,
    FirstName varchar(255),
    LastName varchar(255),
    MiddleName varchar(255),
    Title varchar(20),
    StreetNumber varchar(50),
    StreetName varchar(300),
    Type varchar(100),
    Line2 varchar(100),
    City varchar(100),
    State varchar(100),
    Zip varchar(20),
    Country varchar(100)
);


CREATE TABLE phone (
    ID int  NOT NULL AUTO_INCREMENT PRIMARY KEY,
    addressid int NOT NULL,
    phone varchar(15)
  );
  

CREATE TABLE email (
    ID int  NOT NULL AUTO_INCREMENT PRIMARY KEY,
    addressid int NOT NULL,
    email varchar(150)
  );