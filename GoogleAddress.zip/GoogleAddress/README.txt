
localhost url
http://localhost:8080/address-web/index.jsp


you can do various things from this address bar tool, below are examples for your quick start, this is just the beginning, there is lots of room to enhance this utility

Add records

add mike miller 6501, legacy dr, Apt 108 plano tx 75025
add Cindy Hobbs 6501, legacy dr, Apt 108 plano tx 75025 phone 9725566777 and email dummy@gmail.com
save Carolyn Brady 6501, legacy dr, Apt 108 plano tx 75025 phone 9727766777 office phone 9728889999 and email somemail@yahoo.com and secondmail@hotmail.com
Delete records

delete mike miller from records
Search records

what is the address for phone 4695555555
find the address for phone 4695555555
locate the address for phone 4695555555
search the address for phone 4695555555
what is the address for Carolyn Brady
Find total number of records

total address in the address book
how many address are there in the address book
how many address do i have in my records